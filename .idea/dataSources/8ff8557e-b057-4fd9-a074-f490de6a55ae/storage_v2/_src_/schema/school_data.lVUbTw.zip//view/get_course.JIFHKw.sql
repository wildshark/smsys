create view get_course as
  select
    `school_data`.`course`.`courseID`     AS `courseID`,
    `school_data`.`course`.`progID`       AS `progID`,
    `school_data`.`course`.`course`       AS `course`,
    `school_data`.`course`.`course_code`  AS `course_code`,
    `school_data`.`course`.`credit`       AS `credit`,
    `school_data`.`course`.`course_level` AS `course_level`,
    `school_data`.`course`.`semesterID`   AS `semesterID`,
    `school_data`.`course`.`statusID`     AS `statusID`,
    `school_data`.`programme`.`programme` AS `programme`,
    `school_data`.`semester`.`semester`   AS `semester`,
    `school_data`.`school`.`school`       AS `school`,
    `school_data`.`school`.`prefix`       AS `prefix`
  from (((`school_data`.`course`
    join `school_data`.`programme` on ((`school_data`.`course`.`progID` = `school_data`.`programme`.`progID`))) join
    `school_data`.`semester` on ((`school_data`.`course`.`semesterID` = `school_data`.`semester`.`semesterID`))) join
    `school_data`.`school` on ((`school_data`.`programme`.`schoolID` = `school_data`.`school`.`schoolID`)));

