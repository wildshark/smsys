create view get_hostel_block as
  select
    `school_data`.`hostel_block`.`blockID`    AS `blockID`,
    `school_data`.`hostel_block`.`block_name` AS `block_name`,
    `school_data`.`hostel_block`.`statusID`   AS `statusID`
  from `school_data`.`hostel_block`;

