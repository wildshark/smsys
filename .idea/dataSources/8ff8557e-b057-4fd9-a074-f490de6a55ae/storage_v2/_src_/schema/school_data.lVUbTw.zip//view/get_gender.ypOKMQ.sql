create view get_gender as
  select
    `school_data`.`gender`.`genderID`    AS `genderID`,
    `school_data`.`gender`.`gender_type` AS `gender_type`
  from `school_data`.`gender`;

