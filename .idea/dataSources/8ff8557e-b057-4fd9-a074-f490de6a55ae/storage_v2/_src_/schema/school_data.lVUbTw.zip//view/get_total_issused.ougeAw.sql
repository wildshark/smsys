create view get_total_issused as
  select
    `cal_total_stock_issused_balance`.`stockID`       AS `stockID`,
    `cal_total_stock_issused_balance`.`bal`           AS `bal`,
    `cal_total_stock_issused_balance`.`category_name` AS `category_name`,
    `cal_total_stock_issused_balance`.`stock`         AS `stock`,
    `cal_total_stock_issused_balance`.`code_no`       AS `code_no`
  from `school_data`.`cal_total_stock_issused_balance`
  where (`cal_total_stock_issused_balance`.`bal` > 0);

