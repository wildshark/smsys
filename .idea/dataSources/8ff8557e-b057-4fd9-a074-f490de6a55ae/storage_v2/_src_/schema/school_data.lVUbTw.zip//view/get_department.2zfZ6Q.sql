create view get_department as
  select
    `school_data`.`department`.`departID`   AS `departID`,
    `school_data`.`department`.`department` AS `department`,
    `school_data`.`department`.`schoolID`   AS `schoolID`,
    `school_data`.`department`.`statusID`   AS `statusID`,
    `school_data`.`school`.`school`         AS `school`,
    `school_data`.`school`.`prefix`         AS `prefix`
  from (`school_data`.`department`
    join `school_data`.`school` on ((`school_data`.`department`.`schoolID` = `school_data`.`school`.`schoolID`)));

