create view get_new_student as
  select
    `school_data`.`new_student`.`admissionID`   AS `admissionID`,
    `school_data`.`new_student`.`date`          AS `date`,
    `school_data`.`new_student`.`yearID`        AS `yearID`,
    `school_data`.`new_student`.`progID`        AS `progID`,
    `school_data`.`new_student`.`streaID`       AS `streaID`,
    `school_data`.`new_student`.`proofID`       AS `proofID`,
    `school_data`.`new_student`.`serial_no`     AS `serial_no`,
    `school_data`.`programme`.`programme`       AS `programme`,
    `school_data`.`school`.`school`             AS `school`,
    `school_data`.`school`.`prefix`             AS `prefix`,
    `school_data`.`new_student`.`email`         AS `email`,
    `school_data`.`new_student`.`nationality`   AS `nationality`,
    `school_data`.`new_student`.`exam_result`   AS `exam_result`,
    `school_data`.`new_student`.`categoryID`    AS `categoryID`,
    `school_data`.`new_student`.`f_name`        AS `f_name`,
    `school_data`.`new_student`.`l_name`        AS `l_name`,
    `school_data`.`new_student`.`mobile1`       AS `mobile1`,
    `school_data`.`new_student`.`mobile2`       AS `mobile2`,
    `school_data`.`countries`.`country`         AS `country`,
    `school_data`.`countries`.`nationality`     AS `student_nationality`,
    `school_data`.`new_student`.`attended`      AS `attended`,
    `school_data`.`new_student`.`exam_index_id` AS `exam_index_id`,
    `school_data`.`new_student`.`attended_year` AS `attended_year`
  from (((`school_data`.`new_student`
    join `school_data`.`programme`
      on ((`school_data`.`programme`.`progID` = `school_data`.`new_student`.`progID`))) join `school_data`.`school`
      on ((`school_data`.`school`.`schoolID` = `school_data`.`programme`.`schoolID`))) join `school_data`.`countries`
      on ((`school_data`.`new_student`.`nationality` = `school_data`.`countries`.`countryID`)));

