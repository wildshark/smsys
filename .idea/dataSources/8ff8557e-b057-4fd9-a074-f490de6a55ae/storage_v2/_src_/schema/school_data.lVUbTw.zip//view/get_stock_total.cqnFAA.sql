create view get_stock_total as
  select
    sum(`get_stock_details`.`purchase_qty`) AS `total`,
    `get_stock_details`.`stockID`           AS `stockID`
  from `school_data`.`get_stock_details`
  group by `get_stock_details`.`stockID`;

