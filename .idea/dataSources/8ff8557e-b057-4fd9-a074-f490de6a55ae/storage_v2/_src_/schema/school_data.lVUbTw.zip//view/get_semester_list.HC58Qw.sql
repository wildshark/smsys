create view get_semester_list as
  select
    `school_data`.`semester_list`.`semesterID` AS `semesterID`,
    `school_data`.`semester_list`.`semester`   AS `semester`,
    `school_data`.`semester_list`.`start_date` AS `start_date`,
    `school_data`.`semester_list`.`end_date`   AS `end_date`,
    `school_data`.`semester_list`.`yearID`     AS `yearID`,
    `school_data`.`semester_list`.`statusID`   AS `statusID`
  from `school_data`.`semester_list`;

