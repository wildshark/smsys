create view get_staff_profile as
  select
    `school_data`.`staff_profile`.`staff_profile_ID` AS `staff_profile_ID`,
    `school_data`.`staff_profile`.`employDate`       AS `employDate`,
    `school_data`.`staff_profile`.`staffID`          AS `staffID`,
    `school_data`.`staff_profile`.`f_name`           AS `f_name`,
    `school_data`.`staff_profile`.`l_name`           AS `l_name`,
    `school_data`.`staff_profile`.`marital_status`   AS `marital_status`,
    `school_data`.`staff_profile`.`genderID`         AS `genderID`,
    `school_data`.`staff_profile`.`countryID`        AS `countryID`,
    `school_data`.`staff_profile`.`categoryID`       AS `categoryID`,
    `school_data`.`staff_profile`.`positionID`       AS `positionID`,
    `school_data`.`staff_profile`.`email`            AS `email`,
    `school_data`.`staff_profile`.`mobile1`          AS `mobile1`,
    `school_data`.`staff_profile`.`mobile2`          AS `mobile2`,
    `school_data`.`staff_profile`.`ssn`              AS `ssn`,
    `school_data`.`staff_profile`.`bankID`           AS `bankID`,
    `school_data`.`staff_profile`.`acctName`         AS `acctName`,
    `school_data`.`staff_profile`.`acctNumber`       AS `acctNumber`,
    `school_data`.`staff_profile`.`emerge_name`      AS `emerge_name`,
    `school_data`.`staff_profile`.`emerge_phone`     AS `emerge_phone`,
    `school_data`.`staff_profile`.`emerge_email`     AS `emerge_email`,
    `school_data`.`staff_profile`.`emerge_relation`  AS `emerge_relation`,
    `school_data`.`staff_profile`.`emerge_address`   AS `emerge_address`,
    `school_data`.`staff_profile`.`departmentID`     AS `departmentID`,
    `school_data`.`staff_profile`.`operation_status` AS `operation_status`,
    `school_data`.`staff_profile`.`aos`              AS `aos`,
    `school_data`.`staff_profile`.`photo`            AS `photo`,
    `school_data`.`staff_profile`.`password`         AS `password`,
    `school_data`.`staff_profile`.`token`            AS `token`,
    `school_data`.`staff_profile`.`accessID`         AS `accessID`,
    `school_data`.`countries`.`country`              AS `country`,
    `school_data`.`countries`.`nationality`          AS `nationality`,
    `school_data`.`position_list`.`position`         AS `position`,
    `get_marital_status`.`marital_status`            AS `marital`,
    `school_data`.`get_staff_type`.`staff_type`      AS `staff_type`,
    `school_data`.`staff_profile`.`username`         AS `username`,
    `school_data`.`staff_profile`.`statusID`         AS `statusID`,
    `school_data`.`get_staff_status`.`staff_status`  AS `staff_status`,
    `get_department`.`department`                    AS `department`
  from ((((((`school_data`.`staff_profile`
    join `school_data`.`countries`
      on ((`school_data`.`staff_profile`.`countryID` = `school_data`.`countries`.`countryID`))) join
    `school_data`.`position_list`
      on ((`school_data`.`staff_profile`.`positionID` = `school_data`.`position_list`.`positionID`))) join
    `school_data`.`get_marital_status`
      on ((`school_data`.`staff_profile`.`marital_status` = `get_marital_status`.`categoryID`))) join
    `school_data`.`get_staff_type`
      on ((`school_data`.`staff_profile`.`categoryID` = `school_data`.`get_staff_type`.`categoryID`))) join
    `school_data`.`get_staff_status`
      on ((`school_data`.`staff_profile`.`statusID` = `school_data`.`get_staff_status`.`categoryID`))) join
    `school_data`.`get_department` on ((`school_data`.`staff_profile`.`departmentID` = `get_department`.`departID`)));

