create view get_student_profile_detail as
  select
    `school_data`.`student_profile`.`studentID`     AS `studentID`,
    `school_data`.`student_profile`.`admissionDate` AS `admissionDate`,
    `school_data`.`student_profile`.`first_name`    AS `first_name`,
    `school_data`.`student_profile`.`surname`       AS `surname`,
    `school_data`.`student_profile`.`admissionNo`   AS `admissionNo`,
    `school_data`.`student_profile`.`mobile1`       AS `mobile1`,
    `school_data`.`student_profile`.`mobile2`       AS `mobile2`,
    `school_data`.`student_profile`.`email`         AS `email`,
    `school_data`.`student_profile`.`progID`        AS `progID`,
    `school_data`.`student_profile`.`yearID`        AS `yearID`,
    `school_data`.`student_profile`.`categoryID`    AS `categoryID`,
    `school_data`.`student_profile`.`stream`        AS `stream`,
    `school_data`.`student_profile`.`campus_status` AS `campus_status`,
    `school_data`.`student_profile`.`picture`       AS `picture`,
    `school_data`.`student_profile`.`statusID`      AS `statusID`,
    `school_data`.`programme`.`programme`           AS `programme`,
    `school_data`.`school`.`prefix`                 AS `prefix`
  from ((`school_data`.`student_profile`
    join `school_data`.`programme`
      on ((`school_data`.`student_profile`.`progID` = `school_data`.`programme`.`progID`))) join `school_data`.`school`
      on ((`school_data`.`school`.`schoolID` = `school_data`.`programme`.`schoolID`)));

