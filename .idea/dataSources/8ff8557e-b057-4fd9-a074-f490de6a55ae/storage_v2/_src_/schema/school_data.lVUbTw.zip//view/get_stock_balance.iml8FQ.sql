create view get_stock_balance as
  select
    `school_data`.`stock_details`.`stockID`                                                         AS `stockID`,
    sum(`school_data`.`stock_details`.`purchase_qty`)                                               AS `purchase`,
    sum(`school_data`.`stock_details`.`issue_qty`)                                                  AS `issue`,
    sum((`school_data`.`stock_details`.`purchase_qty` - `school_data`.`stock_details`.`issue_qty`)) AS `bal_qty`,
    `school_data`.`stock_main`.`stock`                                                              AS `stock`
  from (`school_data`.`stock_details`
    join `school_data`.`stock_main`
      on ((`school_data`.`stock_details`.`stockID` = `school_data`.`stock_main`.`stockID`)))
  group by `school_data`.`stock_details`.`stockID`, `school_data`.`stock_main`.`stock`;

