create view get_result_details as
  select
    `school_data`.`result_details`.`resultID`                                                 AS `resultID`,
    `school_data`.`result_details`.`result_semID`                                             AS `result_semID`,
    `school_data`.`result_details`.`yearID`                                                   AS `yearID`,
    `school_data`.`result_details`.`semesterID`                                               AS `semesterID`,
    `school_data`.`result_details`.`courseID`                                                 AS `courseID`,
    `school_data`.`result_details`.`levelID`                                                  AS `levelID`,
    `school_data`.`result_details`.`studentID`                                                AS `studentID`,
    `school_data`.`result_details`.`case_study`                                               AS `case_study`,
    `school_data`.`result_details`.`group_work`                                               AS `group_work`,
    `school_data`.`result_details`.`presentation`                                             AS `presentation`,
    `school_data`.`result_details`.`exam`                                                     AS `exam`,
    ((`school_data`.`result_details`.`case_study` + `school_data`.`result_details`.`group_work`) +
     `school_data`.`result_details`.`presentation`)                                           AS `assessment`,
    (((`school_data`.`result_details`.`case_study` + `school_data`.`result_details`.`group_work`) +
      `school_data`.`result_details`.`presentation`) + `school_data`.`result_details`.`exam`) AS `total`,
    `school_data`.`course`.`course`                                                           AS `course`,
    `school_data`.`course`.`course_code`                                                      AS `course_code`,
    `school_data`.`semester`.`semester`                                                       AS `semester`,
    `school_data`.`student_profile`.`first_name`                                              AS `first_name`,
    `school_data`.`student_profile`.`surname`                                                 AS `surname`,
    `school_data`.`student_profile`.`admissionNo`                                             AS `admissionNo`
  from (((`school_data`.`result_details`
    join `school_data`.`course`
      on ((`school_data`.`course`.`courseID` = `school_data`.`result_details`.`courseID`))) join
    `school_data`.`semester`
      on ((`school_data`.`result_details`.`semesterID` = `school_data`.`semester`.`semesterID`))) join
    `school_data`.`student_profile`
      on ((`school_data`.`result_details`.`studentID` = `school_data`.`student_profile`.`studentID`)));

