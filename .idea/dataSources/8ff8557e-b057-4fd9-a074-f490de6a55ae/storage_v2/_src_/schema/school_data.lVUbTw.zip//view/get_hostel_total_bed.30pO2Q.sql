create view get_hostel_total_bed as
  select
    `school_data`.`hostel_room`.`roomID`                                                   AS `roomID`,
    `school_data`.`hostel_room`.`blockID`                                                  AS `blockID`,
    `school_data`.`hostel_room`.`room`                                                     AS `room`,
    `school_data`.`hostel_room`.`bed`                                                      AS `bed`,
    count(`school_data`.`hostel_detail`.`studentID`)                                       AS `total_user`,
    (`school_data`.`hostel_room`.`bed` - count(`school_data`.`hostel_detail`.`studentID`)) AS `bal_user`,
    `school_data`.`hostel_detail`.`yearID`                                                 AS `yearID`,
    `school_data`.`hostel_block`.`block_name`                                              AS `block_name`
  from ((`school_data`.`hostel_room`
    join `school_data`.`hostel_detail`
      on ((`school_data`.`hostel_room`.`roomID` = `school_data`.`hostel_detail`.`roomID`))) join
    `school_data`.`hostel_block` on ((`school_data`.`hostel_block`.`blockID` = `school_data`.`hostel_room`.`blockID`)))
  group by `school_data`.`hostel_room`.`roomID`, `school_data`.`hostel_room`.`blockID`,
    `school_data`.`hostel_room`.`room`, `school_data`.`hostel_room`.`bed`, `school_data`.`hostel_detail`.`yearID`;

