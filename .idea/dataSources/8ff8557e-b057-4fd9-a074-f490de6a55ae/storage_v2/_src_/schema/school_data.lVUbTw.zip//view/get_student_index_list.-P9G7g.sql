create view get_student_index_list as
  select
    `school_data`.`student_profile`.`studentID`   AS `studentID`,
    `school_data`.`student_profile`.`first_name`  AS `first_name`,
    `school_data`.`student_profile`.`surname`     AS `surname`,
    `school_data`.`student_profile`.`admissionNo` AS `admissionNo`,
    `school_data`.`student_profile`.`statusID`    AS `statusID`
  from `school_data`.`student_profile`
  where (`school_data`.`student_profile`.`statusID` = 1)
  order by `school_data`.`student_profile`.`admissionNo`;

