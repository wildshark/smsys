create view get_result_main as
  select
    `school_data`.`result_main`.`result_semID` AS `result_semID`,
    `school_data`.`result_main`.`result_date`  AS `result_date`,
    `school_data`.`result_main`.`schoolID`     AS `schoolID`,
    `school_data`.`result_main`.`staffID`      AS `staffID`,
    `school_data`.`result_main`.`levelID`      AS `levelID`,
    `school_data`.`result_main`.`yearID`       AS `yearID`,
    `school_data`.`result_main`.`semesterID`   AS `semesterID`,
    `school_data`.`result_main`.`courseID`     AS `courseID`,
    `school_data`.`school`.`school`            AS `school`,
    `school_data`.`school`.`prefix`            AS `prefix`,
    `school_data`.`staff_profile`.`f_name`     AS `f_name`,
    `school_data`.`staff_profile`.`l_name`     AS `l_name`,
    `school_data`.`semester_list`.`semester`   AS `semester`,
    `school_data`.`course`.`course`            AS `course`,
    `school_data`.`course`.`course_code`       AS `course_code`
  from ((((`school_data`.`result_main`
    join `school_data`.`school` on ((`school_data`.`result_main`.`schoolID` = `school_data`.`school`.`schoolID`))) join
    `school_data`.`staff_profile`
      on ((`school_data`.`result_main`.`staffID` = `school_data`.`staff_profile`.`staff_profile_ID`))) join
    `school_data`.`semester_list`
      on ((`school_data`.`result_main`.`semesterID` = `school_data`.`semester_list`.`semesterID`))) join
    `school_data`.`course` on ((`school_data`.`result_main`.`courseID` = `school_data`.`course`.`courseID`)));

