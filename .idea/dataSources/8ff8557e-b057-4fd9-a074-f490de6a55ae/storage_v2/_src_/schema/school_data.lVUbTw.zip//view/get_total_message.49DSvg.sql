create view get_total_message as
  select
    count(`school_data`.`message`.`msgDate`) AS `total`,
    `school_data`.`message`.`stateID`        AS `stateID`,
    `school_data`.`message`.`userID`         AS `userID`
  from `school_data`.`message`
  where (`school_data`.`message`.`stateID` = 1);

