create view get_course_table as
  select
    `school_data`.`course`.`courseID`     AS `courseID`,
    `school_data`.`course`.`progID`       AS `progID`,
    `school_data`.`course`.`course`       AS `course`,
    `school_data`.`course`.`course_code`  AS `course_code`,
    `school_data`.`course`.`course_level` AS `course_level`,
    `school_data`.`course`.`semesterID`   AS `semesterID`,
    `school_data`.`course`.`credit`       AS `credit`,
    `school_data`.`course`.`profileID`    AS `profileID`,
    `school_data`.`course`.`dayID`        AS `dayID`,
    `school_data`.`course`.`time`         AS `time`,
    `school_data`.`course`.`statusID`     AS `statusID`
  from `school_data`.`course`;

