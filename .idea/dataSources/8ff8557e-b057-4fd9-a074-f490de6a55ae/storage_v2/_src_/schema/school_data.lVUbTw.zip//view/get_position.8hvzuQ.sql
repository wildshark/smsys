create view get_position as
  select
    `school_data`.`position_list`.`positionID` AS `positionID`,
    `school_data`.`position_list`.`position`   AS `position`,
    `school_data`.`position_list`.`statusId`   AS `statusId`
  from `school_data`.`position_list`;

