create view get_position as
  select
    `school_data`.`position_list`.`positionID`    AS `positionID`,
    `school_data`.`position_list`.`position`      AS `position`,
    `school_data`.`position_list`.`statusId`      AS `statusId`,
    `school_data`.`position_list`.`categoryID`    AS `categoryID`,
    `school_data`.`category_list`.`category_name` AS `category_name`
  from (`school_data`.`position_list`
    join `school_data`.`category_list`
      on ((`school_data`.`position_list`.`categoryID` = `school_data`.`category_list`.`categoryID`)));

