create view get_staff_terminated as
  select
    `school_data`.`staff_profile`.`staff_profile_ID` AS `staff_profile_ID`,
    `school_data`.`staff_profile`.`employDate`       AS `employDate`,
    `school_data`.`staff_profile`.`staffID`          AS `staffID`,
    `school_data`.`staff_profile`.`f_name`           AS `f_name`,
    `school_data`.`staff_profile`.`l_name`           AS `l_name`,
    `school_data`.`staff_profile`.`marital_status`   AS `marital_status`,
    `school_data`.`staff_profile`.`genderID`         AS `genderID`,
    `school_data`.`staff_profile`.`countryID`        AS `countryID`,
    `school_data`.`staff_profile`.`categoryID`       AS `categoryID`,
    `school_data`.`staff_profile`.`positionID`       AS `positionID`,
    `school_data`.`staff_profile`.`departmentID`     AS `departmentID`,
    `school_data`.`staff_profile`.`operation_status` AS `operation_status`,
    `school_data`.`staff_profile`.`aos`              AS `aos`,
    `school_data`.`staff_profile`.`email`            AS `email`,
    `school_data`.`staff_profile`.`mobile1`          AS `mobile1`,
    `school_data`.`staff_profile`.`mobile2`          AS `mobile2`,
    `school_data`.`staff_profile`.`ssn`              AS `ssn`,
    `school_data`.`staff_profile`.`bankID`           AS `bankID`,
    `school_data`.`staff_profile`.`acctName`         AS `acctName`,
    `school_data`.`staff_profile`.`acctNumber`       AS `acctNumber`,
    `school_data`.`staff_profile`.`emerge_name`      AS `emerge_name`,
    `school_data`.`staff_profile`.`emerge_phone`     AS `emerge_phone`,
    `school_data`.`staff_profile`.`emerge_email`     AS `emerge_email`,
    `school_data`.`staff_profile`.`emerge_relation`  AS `emerge_relation`,
    `school_data`.`staff_profile`.`emerge_address`   AS `emerge_address`,
    `school_data`.`staff_profile`.`photo`            AS `photo`,
    `school_data`.`staff_profile`.`username`         AS `username`,
    `school_data`.`staff_profile`.`password`         AS `password`,
    `school_data`.`staff_profile`.`token`            AS `token`,
    `school_data`.`staff_profile`.`accessID`         AS `accessID`,
    `school_data`.`staff_profile`.`statusID`         AS `statusID`,
    `school_data`.`countries`.`nationality`          AS `nationality`,
    `school_data`.`department`.`department`          AS `department`,
    `school_data`.`category_list`.`category_name`    AS `staff_type`,
    `get_position`.`position`                        AS `position`
  from ((((`school_data`.`staff_profile`
    join `school_data`.`countries`
      on ((`school_data`.`staff_profile`.`countryID` = `school_data`.`countries`.`countryID`))) join
    `school_data`.`department`
      on ((`school_data`.`staff_profile`.`departmentID` = `school_data`.`department`.`departID`))) join
    `school_data`.`category_list`
      on ((`school_data`.`staff_profile`.`categoryID` = `school_data`.`category_list`.`categoryID`))) join
    `school_data`.`get_position` on ((`school_data`.`staff_profile`.`positionID` = `get_position`.`positionID`)));

