create view get_hostel_room as
  select
    `school_data`.`hostel_room`.`roomID`      AS `roomID`,
    `school_data`.`hostel_room`.`blockID`     AS `blockID`,
    `school_data`.`hostel_room`.`room`        AS `room`,
    `school_data`.`hostel_room`.`bed`         AS `bed`,
    `school_data`.`hostel_block`.`block_name` AS `block_name`
  from (`school_data`.`hostel_room`
    join `school_data`.`hostel_block`
      on ((`school_data`.`hostel_room`.`blockID` = `school_data`.`hostel_block`.`blockID`)));

