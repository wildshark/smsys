create view get_school as
  select
    `school_data`.`school`.`schoolID` AS `schoolID`,
    `school_data`.`school`.`school`   AS `school`,
    `school_data`.`school`.`prefix`   AS `prefix`,
    `school_data`.`school`.`statusID` AS `statusID`,
    `school_data`.`school`.`catID`    AS `catID`
  from `school_data`.`school`
  where (`school_data`.`school`.`catID` = 1);

