create view get_day_list as
  select
    `school_data`.`day_list`.`dayID`    AS `dayID`,
    `school_data`.`day_list`.`day_type` AS `day_type`
  from `school_data`.`day_list`;

