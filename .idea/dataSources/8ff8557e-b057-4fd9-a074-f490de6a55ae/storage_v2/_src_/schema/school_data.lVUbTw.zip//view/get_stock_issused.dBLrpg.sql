create view get_stock_issused as
  select
    `school_data`.`stock_details`.`tranID`         AS `tranID`,
    `school_data`.`stock_details`.`sys_date`       AS `sys_date`,
    `school_data`.`stock_details`.`tran_date`      AS `tran_date`,
    `school_data`.`stock_details`.`stockID`        AS `stockID`,
    `school_data`.`stock_details`.`details`        AS `details`,
    `school_data`.`stock_details`.`ref_no`         AS `ref_no`,
    `school_data`.`stock_details`.`issue_qty`      AS `issue_qty`,
    `school_data`.`stock_details`.`staffID`        AS `staffID`,
    `school_data`.`stock_details`.`remarks`        AS `remarks`,
    `school_data`.`stock_details`.`status`         AS `status`,
    `school_data`.`stock_main`.`code_no`           AS `code_no`,
    `school_data`.`stock_main`.`stock`             AS `stock`,
    `school_data`.`stock_category`.`category_name` AS `stock_category`,
    `school_data`.`staff_profile`.`f_name`         AS `f_name`,
    `school_data`.`staff_profile`.`l_name`         AS `l_name`
  from (((`school_data`.`stock_details`
    join `school_data`.`stock_main`
      on ((`school_data`.`stock_details`.`stockID` = `school_data`.`stock_main`.`stockID`))) join
    `school_data`.`stock_category`
      on ((`school_data`.`stock_main`.`categoryID` = `school_data`.`stock_category`.`categoryID`))) join
    `school_data`.`staff_profile`
      on ((`school_data`.`stock_details`.`staffID` = `school_data`.`staff_profile`.`staff_profile_ID`)))
  where (`school_data`.`stock_details`.`issue_qty` > 0);

