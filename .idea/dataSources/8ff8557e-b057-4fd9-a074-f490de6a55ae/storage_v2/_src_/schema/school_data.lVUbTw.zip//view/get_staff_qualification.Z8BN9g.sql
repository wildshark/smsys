create view get_staff_qualification as
  select
    `school_data`.`staff_qualification`.`qualificationID` AS `qualificationID`,
    `school_data`.`staff_qualification`.`profileID`       AS `profileID`,
    `school_data`.`staff_qualification`.`year`            AS `year`,
    `school_data`.`staff_qualification`.`school`          AS `school`,
    `school_data`.`staff_qualification`.`qualification`   AS `qualification`
  from `school_data`.`staff_qualification`;

