create view get_stock_purchase as
  select
    `school_data`.`stock_details`.`tranID`           AS `tranID`,
    `school_data`.`stock_details`.`supplyID`         AS `supplyID`,
    `school_data`.`stock_details`.`sys_date`         AS `sys_date`,
    `school_data`.`stock_details`.`tran_date`        AS `tran_date`,
    `school_data`.`stock_details`.`stockID`          AS `stockID`,
    `school_data`.`stock_details`.`details`          AS `details`,
    `school_data`.`stock_details`.`unit_price`       AS `unit_price`,
    `school_data`.`stock_details`.`ref_no`           AS `ref_no`,
    `school_data`.`stock_details`.`purchase_qty`     AS `purchase_qty`,
    `school_data`.`stock_details`.`remarks`          AS `remarks`,
    `school_data`.`stock_details`.`status`           AS `status`,
    `school_data`.`stock_main`.`stock`               AS `stock`,
    `school_data`.`stock_main`.`code_no`             AS `code_no`,
    `school_data`.`stock_category`.`category_name`   AS `category_name`,
    `school_data`.`supplier_contact`.`supplier_name` AS `supplier_name`,
    `school_data`.`supplier_contact`.`address`       AS `address`,
    `school_data`.`supplier_contact`.`mobile1`       AS `mobile1`
  from (((`school_data`.`stock_details`
    join `school_data`.`stock_main`
      on ((`school_data`.`stock_details`.`stockID` = `school_data`.`stock_main`.`stockID`))) join
    `school_data`.`stock_category`
      on ((`school_data`.`stock_main`.`categoryID` = `school_data`.`stock_category`.`categoryID`))) join
    `school_data`.`supplier_contact`
      on ((`school_data`.`stock_details`.`supplyID` = `school_data`.`supplier_contact`.`supplyID`)))
  where (`school_data`.`stock_details`.`purchase_qty` > 0);

