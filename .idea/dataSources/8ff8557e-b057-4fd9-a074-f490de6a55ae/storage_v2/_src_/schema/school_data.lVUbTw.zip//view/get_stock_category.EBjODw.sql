create view get_stock_category as
  select
    `school_data`.`stock_category`.`categoryID`    AS `categoryID`,
    `school_data`.`stock_category`.`category_name` AS `category_name`,
    `school_data`.`stock_category`.`stateID`       AS `stateID`
  from `school_data`.`stock_category`;

