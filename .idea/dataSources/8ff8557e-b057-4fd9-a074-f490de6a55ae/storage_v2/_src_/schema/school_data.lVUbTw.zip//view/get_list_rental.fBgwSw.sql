create view get_list_rental as
  select
    `school_data`.`list_rental`.`rental_typeID` AS `rentalID`,
    `school_data`.`list_rental`.`rental_type`   AS `rental_type`,
    `school_data`.`list_rental`.`statusID`      AS `statusID`
  from `school_data`.`list_rental`;

