create view get_lecture_note as
  select
    `school_data`.`lecture_note`.`lectureID` AS `lectureID`,
    `school_data`.`lecture_note`.`lect_date` AS `lect_date`,
    `school_data`.`lecture_note`.`staffID`   AS `staffID`,
    `school_data`.`lecture_note`.`departID`  AS `departID`,
    `school_data`.`lecture_note`.`title`     AS `title`,
    `school_data`.`lecture_note`.`semester`  AS `semesterID`,
    `school_data`.`lecture_note`.`levelID`   AS `levelID`,
    `school_data`.`lecture_note`.`file_path` AS `file_path`,
    `school_data`.`department`.`department`  AS `department`,
    `school_data`.`staff_profile`.`f_name`   AS `f_name`,
    `school_data`.`staff_profile`.`l_name`   AS `l_name`,
    `school_data`.`semester`.`semester`      AS `semester`
  from (((`school_data`.`lecture_note`
    join `school_data`.`department`
      on ((`school_data`.`lecture_note`.`departID` = `school_data`.`department`.`departID`))) join
    `school_data`.`staff_profile`
      on ((`school_data`.`lecture_note`.`staffID` = `school_data`.`staff_profile`.`staff_profile_ID`))) join
    `school_data`.`semester` on ((`school_data`.`lecture_note`.`semester` = `school_data`.`semester`.`semesterID`)));

