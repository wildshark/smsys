create view get_lecture_note as
  select
    `school_data`.`lecture_note`.`lectureID` AS `lectureID`,
    `school_data`.`lecture_note`.`lect_date` AS `lect_date`,
    `school_data`.`lecture_note`.`staffID`   AS `staffID`,
    `school_data`.`lecture_note`.`title`     AS `title`,
    `school_data`.`lecture_note`.`semester`  AS `semesterID`,
    `school_data`.`lecture_note`.`levelID`   AS `levelID`,
    `school_data`.`lecture_note`.`file_path` AS `file_path`,
    `school_data`.`staff_profile`.`f_name`   AS `f_name`,
    `school_data`.`staff_profile`.`l_name`   AS `l_name`,
    `school_data`.`semester`.`semester`      AS `semester`,
    `school_data`.`lecture_note`.`courseID`  AS `courseID`,
    `school_data`.`course`.`course`          AS `course`,
    `school_data`.`course`.`course_code`     AS `course_code`,
    `school_data`.`programme`.`programme`    AS `programme`,
    `school_data`.`school`.`school`          AS `school`,
    `school_data`.`school`.`prefix`          AS `prefix`
  from (((((`school_data`.`lecture_note`
    join `school_data`.`staff_profile`
      on ((`school_data`.`lecture_note`.`staffID` = `school_data`.`staff_profile`.`staff_profile_ID`))) join
    `school_data`.`semester`
      on ((`school_data`.`lecture_note`.`semester` = `school_data`.`semester`.`semesterID`))) join
    `school_data`.`course` on ((`school_data`.`course`.`courseID` = `school_data`.`lecture_note`.`courseID`))) join
    `school_data`.`programme` on ((`school_data`.`programme`.`progID` = `school_data`.`course`.`progID`))) join
    `school_data`.`school` on ((`school_data`.`school`.`schoolID` = `school_data`.`programme`.`schoolID`)));

