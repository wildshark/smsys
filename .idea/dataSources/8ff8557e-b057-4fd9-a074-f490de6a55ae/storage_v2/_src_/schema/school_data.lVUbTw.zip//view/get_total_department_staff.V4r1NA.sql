create view get_total_department_staff as
  select
    count(`school_data`.`staff_profile`.`staff_profile_ID`) AS `total`,
    `school_data`.`staff_profile`.`departmentID`            AS `departmentID`
  from `school_data`.`staff_profile`
  group by `school_data`.`staff_profile`.`departmentID`;

