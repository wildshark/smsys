create view get_stock_list as
  select
    `school_data`.`stock_main`.`stockID` AS `stockID`,
    `school_data`.`stock_main`.`stock`   AS `stock`,
    `school_data`.`stock_main`.`status`  AS `status`
  from `school_data`.`stock_main`;

