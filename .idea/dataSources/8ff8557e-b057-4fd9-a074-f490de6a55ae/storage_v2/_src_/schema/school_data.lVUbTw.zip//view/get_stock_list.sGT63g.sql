create view get_stock_list as
  select
    `school_data`.`stock_main`.`stockID`           AS `stockID`,
    `school_data`.`stock_main`.`stock`             AS `stock`,
    `school_data`.`stock_main`.`status`            AS `status`,
    `school_data`.`stock_main`.`categoryID`        AS `categoryID`,
    `school_data`.`stock_main`.`code_no`           AS `code_no`,
    `school_data`.`stock_category`.`category_name` AS `category_name`
  from (`school_data`.`stock_main`
    join `school_data`.`stock_category`
      on ((`school_data`.`stock_main`.`categoryID` = `school_data`.`stock_category`.`categoryID`)));

