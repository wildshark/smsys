create view cal_total_stock_issused_balance as
  select
    `school_data`.`stock_details`.`stockID`                                                         AS `stockID`,
    sum((`school_data`.`stock_details`.`purchase_qty` - `school_data`.`stock_details`.`issue_qty`)) AS `bal`,
    `school_data`.`stock_category`.`category_name`                                                  AS `category_name`,
    `school_data`.`stock_main`.`stock`                                                              AS `stock`,
    `school_data`.`stock_main`.`code_no`                                                            AS `code_no`
  from ((`school_data`.`stock_details`
    join `school_data`.`stock_main`
      on ((`school_data`.`stock_details`.`stockID` = `school_data`.`stock_main`.`stockID`))) join
    `school_data`.`stock_category`
      on ((`school_data`.`stock_main`.`categoryID` = `school_data`.`stock_category`.`categoryID`)))
  group by `school_data`.`stock_details`.`stockID`;

