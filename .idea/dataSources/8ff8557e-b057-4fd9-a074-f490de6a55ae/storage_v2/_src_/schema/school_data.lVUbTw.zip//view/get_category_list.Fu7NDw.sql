create view get_category_list as
  select
    `school_data`.`category_list`.`categoryID`       AS `categoryID`,
    `school_data`.`category_list`.`category_name`    AS `category_name`,
    `school_data`.`category_list`.`classificationID` AS `classificationID`
  from `school_data`.`category_list`;

