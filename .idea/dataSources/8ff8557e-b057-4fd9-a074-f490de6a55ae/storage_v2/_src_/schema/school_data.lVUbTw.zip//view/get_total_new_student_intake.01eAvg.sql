create view get_total_new_student_intake as
  select
    count(`school_data`.`new_student`.`admissionID`) AS `total_student`,
    `school_data`.`new_student`.`yearID`             AS `yearID`,
    `school_data`.`new_student`.`progID`             AS `progID`
  from `school_data`.`new_student`
  group by `school_data`.`new_student`.`yearID`, `school_data`.`new_student`.`progID`;

