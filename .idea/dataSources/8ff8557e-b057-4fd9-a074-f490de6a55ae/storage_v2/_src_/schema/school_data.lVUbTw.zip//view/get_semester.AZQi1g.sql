create view get_semester as
  select
    `school_data`.`semester`.`semesterID` AS `semesterID`,
    `school_data`.`semester`.`semester`   AS `semester`
  from `school_data`.`semester`;

