create view get_staff_type as
  select
    `school_data`.`category_list`.`categoryID`       AS `categoryID`,
    `school_data`.`category_list`.`category_name`    AS `staff_type`,
    `school_data`.`category_list`.`classificationID` AS `classificationID`
  from `school_data`.`category_list`
  where (`school_data`.`category_list`.`classificationID` = 2);

