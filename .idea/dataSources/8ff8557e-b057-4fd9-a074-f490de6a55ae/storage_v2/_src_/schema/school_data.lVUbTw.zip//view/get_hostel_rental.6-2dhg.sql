create view get_hostel_rental as
  select
    (`school_data`.`hostel_rental`.`end_date` - curdate()) AS `NoOfDays`,
    `school_data`.`hostel_rental`.`rentalID`               AS `rentalID`,
    `school_data`.`hostel_rental`.`refNo`                  AS `refNo`,
    `school_data`.`hostel_rental`.`tranDate`               AS `tranDate`,
    `school_data`.`hostel_rental`.`church_name`            AS `church_name`,
    `school_data`.`hostel_rental`.`people`                 AS `people`,
    `school_data`.`hostel_rental`.`amount`                 AS `amount`,
    `school_data`.`hostel_rental`.`discount`               AS `discount`,
    `school_data`.`hostel_rental`.`start_date`             AS `start_date`,
    `school_data`.`hostel_rental`.`end_date`               AS `end_date`,
    `school_data`.`hostel_rental`.`statusID`               AS `statusID`,
    `school_data`.`hostel_rental`.`contact_address`        AS `contact_address`,
    `school_data`.`hostel_rental`.`mobile1`                AS `mobile1`,
    `school_data`.`hostel_rental`.`mobile2`                AS `mobile2`,
    `school_data`.`hostel_rental`.`rental_typeID`          AS `rental_typeID`,
    `school_data`.`list_rental`.`rental_type`              AS `rental_type`
  from (`school_data`.`hostel_rental`
    join `school_data`.`list_rental`
      on ((`school_data`.`list_rental`.`rental_typeID` = `school_data`.`hostel_rental`.`rental_typeID`)))
  where (`school_data`.`hostel_rental`.`statusID` = 1);

