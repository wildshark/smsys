create view get_hostel_rental as
  select
    (`school_data`.`hostel_rental`.`end_date` - curdate()) AS `NoOfDays`,
    `school_data`.`hostel_rental`.`rentalID`               AS `rentalID`,
    `school_data`.`hostel_rental`.`refNo`                  AS `refNo`,
    `school_data`.`hostel_rental`.`tranDate`               AS `tranDate`,
    `school_data`.`hostel_rental`.`group`                  AS `group`,
    `school_data`.`hostel_rental`.`people`                 AS `people`,
    `school_data`.`hostel_rental`.`amount`                 AS `amount`,
    `school_data`.`hostel_rental`.`discount`               AS `discount`,
    `school_data`.`hostel_rental`.`start_date`             AS `start_date`,
    `school_data`.`hostel_rental`.`end_date`               AS `end_date`,
    `school_data`.`hostel_rental`.`statusID`               AS `statusID`
  from `school_data`.`hostel_rental`;

