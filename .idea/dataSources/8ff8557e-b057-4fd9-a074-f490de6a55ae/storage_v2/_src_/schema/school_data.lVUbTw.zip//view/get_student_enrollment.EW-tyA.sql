create view get_student_enrollment as
  select
    `school_data`.`enrollment`.`enrollID`                AS `enrollID`,
    `school_data`.`enrollment`.`enroll_date`             AS `enroll_date`,
    `school_data`.`enrollment`.`studentID`               AS `studentID`,
    `school_data`.`enrollment`.`semesterID`              AS `semesterID`,
    `school_data`.`enrollment`.`yearID`                  AS `yearID`,
    `school_data`.`enrollment`.`progID`                  AS `progID`,
    `school_data`.`programme`.`programme`                AS `programme`,
    `school_data`.`semester`.`semester`                  AS `semester`,
    `school_data`.`get_student_index_list`.`first_name`  AS `first_name`,
    `school_data`.`get_student_index_list`.`surname`     AS `surname`,
    `school_data`.`get_student_index_list`.`admissionNo` AS `admissionNo`,
    `school_data`.`school`.`prefix`                      AS `prefix`
  from ((((`school_data`.`enrollment`
    join `school_data`.`programme` on ((`school_data`.`enrollment`.`progID` = `school_data`.`programme`.`progID`))) join
    `school_data`.`semester`
      on ((`school_data`.`semester`.`semesterID` = `school_data`.`enrollment`.`semesterID`))) join
    `school_data`.`get_student_index_list`
      on ((`school_data`.`enrollment`.`studentID` = `school_data`.`get_student_index_list`.`studentID`))) join
    `school_data`.`school` on ((`school_data`.`programme`.`schoolID` = `school_data`.`school`.`schoolID`)));

