create view get_qualification as
  select
    `school_data`.`qualification`.`qualification_ID` AS `qualification_ID`,
    `school_data`.`qualification`.`staff_profile_ID` AS `staff_profile_ID`,
    `school_data`.`qualification`.`qualification`    AS `qualification`,
    `school_data`.`qualification`.`place`            AS `place`,
    `school_data`.`qualification`.`year`             AS `year`
  from `school_data`.`qualification`;

