create view get_academic_session as
  select
    `school_data`.`academic_session`.`yearID`   AS `yearID`,
    `school_data`.`academic_session`.`year`     AS `year`,
    `school_data`.`academic_session`.`statusID` AS `statusID`
  from `school_data`.`academic_session`
  where (`school_data`.`academic_session`.`statusID` = 2);

