create view get_total_student as
  select
    count(`school_data`.`student_profile`.`studentID`) AS `total`,
    `school_data`.`student_profile`.`yearID`           AS `yearID`,
    `school_data`.`student_profile`.`progID`           AS `progID`
  from `school_data`.`student_profile`
  where (`school_data`.`student_profile`.`statusID` <> 0)
  group by `school_data`.`student_profile`.`yearID`, `school_data`.`student_profile`.`progID`,
    `school_data`.`student_profile`.`statusID`;

