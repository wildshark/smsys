create view get_supplier_contact as
  select
    `school_data`.`supplier_contact`.`supplyID`      AS `supplyID`,
    `school_data`.`supplier_contact`.`supplier_name` AS `supplier_name`,
    `school_data`.`supplier_contact`.`address`       AS `address`,
    `school_data`.`supplier_contact`.`mobile1`       AS `mobile1`,
    `school_data`.`supplier_contact`.`mobile2`       AS `mobile2`,
    `school_data`.`supplier_contact`.`email`         AS `email`
  from `school_data`.`supplier_contact`;

