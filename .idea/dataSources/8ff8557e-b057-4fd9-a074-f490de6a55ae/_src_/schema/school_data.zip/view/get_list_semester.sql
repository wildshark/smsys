CREATE VIEW get_list_semester AS
  SELECT
    `school_data`.`semester`.`semesterID` AS `semesterID`,
    `school_data`.`semester`.`semester`   AS `semester`
  FROM `school_data`.`semester`;
