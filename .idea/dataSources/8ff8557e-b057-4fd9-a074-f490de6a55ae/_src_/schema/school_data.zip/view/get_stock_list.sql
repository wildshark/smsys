CREATE VIEW get_stock_list AS
  SELECT
    `school_data`.`stock_main`.`stockID` AS `stockID`,
    `school_data`.`stock_main`.`stock`   AS `stock`,
    `school_data`.`stock_main`.`status`  AS `status`
  FROM `school_data`.`stock_main`;
