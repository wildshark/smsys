CREATE VIEW get_academic_session AS
  SELECT
    `school_data`.`academic_session`.`yearID`   AS `yearID`,
    `school_data`.`academic_session`.`year`     AS `year`,
    `school_data`.`academic_session`.`statusID` AS `statusID`
  FROM `school_data`.`academic_session`
  WHERE (`school_data`.`academic_session`.`statusID` = 2);
