CREATE VIEW get_staff_qualification AS
  SELECT
    `school_data`.`staff_qualification`.`qualificationID` AS `qualificationID`,
    `school_data`.`staff_qualification`.`profileID`       AS `profileID`,
    `school_data`.`staff_qualification`.`year`            AS `year`,
    `school_data`.`staff_qualification`.`school`          AS `school`,
    `school_data`.`staff_qualification`.`qualification`   AS `qualification`
  FROM `school_data`.`staff_qualification`;
