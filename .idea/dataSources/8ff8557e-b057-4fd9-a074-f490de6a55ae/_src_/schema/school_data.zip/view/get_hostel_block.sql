CREATE VIEW get_hostel_block AS
  SELECT
    `school_data`.`hostel_block`.`blockID`    AS `blockID`,
    `school_data`.`hostel_block`.`block_name` AS `block_name`,
    `school_data`.`hostel_block`.`statusID`   AS `statusID`
  FROM `school_data`.`hostel_block`;
