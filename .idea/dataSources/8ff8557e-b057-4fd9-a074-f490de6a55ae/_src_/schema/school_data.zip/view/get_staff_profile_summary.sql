CREATE VIEW get_staff_profile_summary AS
  SELECT
    `school_data`.`staff_profile`.`staff_profile_ID` AS `staff_profile_ID`,
    `school_data`.`staff_profile`.`staffID`          AS `staffID`,
    `school_data`.`staff_profile`.`f_name`           AS `f_name`,
    `school_data`.`staff_profile`.`l_name`           AS `l_name`,
    `school_data`.`staff_profile`.`access`           AS `access`
  FROM `school_data`.`staff_profile`;
