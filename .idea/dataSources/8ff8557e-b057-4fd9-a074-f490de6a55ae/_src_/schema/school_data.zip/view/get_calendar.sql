CREATE VIEW get_calendar AS
  SELECT
    `school_data`.`calendar`.`calendarID`    AS `calendarID`,
    `school_data`.`calendar`.`semester_year` AS `semester_year`,
    `school_data`.`calendar`.`semesterID`    AS `semesterID`,
    `school_data`.`calendar`.`activities`    AS `activities`,
    `school_data`.`calendar`.`start_date`    AS `start_date`,
    `school_data`.`calendar`.`end_date`      AS `end_date`,
    `school_data`.`calendar`.`statusID`      AS `statusID`,
    `school_data`.`semester`.`semester`      AS `semester`
  FROM (`school_data`.`calendar`
    JOIN `school_data`.`semester` ON ((`school_data`.`calendar`.`semesterID` = `school_data`.`semester`.`semesterID`)));
