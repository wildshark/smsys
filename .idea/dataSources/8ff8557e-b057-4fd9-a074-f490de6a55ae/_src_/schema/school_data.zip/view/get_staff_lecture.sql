CREATE VIEW get_staff_lecture AS
  SELECT
    `school_data`.`staff_profile`.`staff_profile_ID` AS `staff_profile_ID`,
    `school_data`.`staff_profile`.`staffID`          AS `staffID`,
    `school_data`.`staff_profile`.`f_name`           AS `f_name`,
    `school_data`.`staff_profile`.`l_name`           AS `l_name`,
    `school_data`.`staff_profile`.`categoryID`       AS `categoryID`,
    `school_data`.`staff_profile`.`departmentID`     AS `departmentID`,
    `school_data`.`staff_profile`.`aos`              AS `aos`
  FROM `school_data`.`staff_profile`
  WHERE (`school_data`.`staff_profile`.`categoryID` = 1);
