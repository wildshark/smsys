CREATE VIEW get_department AS
  SELECT
    `school_data`.`department`.`departID`   AS `departID`,
    `school_data`.`department`.`department` AS `department`,
    `school_data`.`department`.`schoolID`   AS `schoolID`,
    `school_data`.`department`.`statusID`   AS `statusID`,
    `school_data`.`school`.`school`         AS `school`,
    `school_data`.`school`.`prefix`         AS `prefix`
  FROM (`school_data`.`department`
    JOIN `school_data`.`school` ON ((`school_data`.`department`.`schoolID` = `school_data`.`school`.`schoolID`)));
