CREATE VIEW get_hostel_booking AS
  SELECT
    `school_data`.`hostel_detail`.`userID`               AS `userID`,
    `school_data`.`hostel_detail`.`tran_date`            AS `tran_date`,
    `school_data`.`hostel_detail`.`date`                 AS `date`,
    `school_data`.`hostel_detail`.`studentID`            AS `studentID`,
    `school_data`.`hostel_detail`.`roomID`               AS `roomID`,
    `school_data`.`hostel_detail`.`book_in`              AS `book_in`,
    `school_data`.`hostel_detail`.`book_out`             AS `book_out`,
    `school_data`.`hostel_detail`.`ref_no`               AS `ref_no`,
    `school_data`.`hostel_detail`.`status`               AS `status`,
    `school_data`.`get_hostel_room`.`room`               AS `room`,
    `school_data`.`get_hostel_room`.`block_name`         AS `block_name`,
    `school_data`.`get_student_index_list`.`first_name`  AS `first_name`,
    `school_data`.`get_student_index_list`.`surname`     AS `surname`,
    `school_data`.`get_student_index_list`.`admissionNo` AS `admissionNo`
  FROM ((`school_data`.`hostel_detail`
    JOIN `school_data`.`get_hostel_room`
      ON ((`school_data`.`hostel_detail`.`roomID` = `school_data`.`get_hostel_room`.`roomID`))) JOIN
    `school_data`.`get_student_index_list`
      ON ((`school_data`.`hostel_detail`.`studentID` = `school_data`.`get_student_index_list`.`studentID`)));
