CREATE VIEW get_stock_details AS
  SELECT
    `school_data`.`stock_details`.`tranID`       AS `tranID`,
    `school_data`.`stock_details`.`sys_date`     AS `sys_date`,
    `school_data`.`stock_details`.`tran_date`    AS `tran_date`,
    `school_data`.`stock_details`.`stockID`      AS `stockID`,
    `school_data`.`stock_details`.`ref_no`       AS `ref_no`,
    `school_data`.`stock_details`.`order_qty`    AS `order_qty`,
    `school_data`.`stock_details`.`purchase_qty` AS `purchase_qty`,
    `school_data`.`stock_details`.`issue_qty`    AS `issue_qty`,
    `school_data`.`stock_details`.`status`       AS `status`,
    `school_data`.`stock_main`.`stock`           AS `stock`,
    `school_data`.`stock_details`.`details`      AS `details`
  FROM (`school_data`.`stock_details`
    JOIN `school_data`.`stock_main`
      ON ((`school_data`.`stock_details`.`stockID` = `school_data`.`stock_main`.`stockID`)));
