CREATE VIEW get_admin AS
  SELECT
    `school_data`.`admin`.`userID`   AS `userID`,
    `school_data`.`admin`.`username` AS `username`,
    `school_data`.`admin`.`password` AS `password`,
    `school_data`.`admin`.`email`    AS `email`,
    `school_data`.`admin`.`access`   AS `access`,
    `school_data`.`admin`.`status`   AS `status`
  FROM `school_data`.`admin`;
