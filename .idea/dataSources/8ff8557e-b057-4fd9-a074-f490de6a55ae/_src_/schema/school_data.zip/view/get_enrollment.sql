CREATE VIEW get_enrollment AS
  SELECT
    `school_data`.`enrollment`.`enrollID`    AS `enrollID`,
    `school_data`.`enrollment`.`enroll_date` AS `enroll_date`,
    `school_data`.`enrollment`.`studentID`   AS `studentID`,
    `school_data`.`enrollment`.`semesterID`  AS `semesterID`,
    `school_data`.`enrollment`.`academic_yr` AS `academic_yr`,
    `school_data`.`enrollment`.`courseID`    AS `courseID`
  FROM `school_data`.`enrollment`;
