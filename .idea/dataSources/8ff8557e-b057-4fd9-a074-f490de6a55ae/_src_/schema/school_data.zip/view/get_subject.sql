CREATE VIEW get_subject AS
  SELECT
    `school_data`.`subject`.`subjectID`    AS `subjectID`,
    `school_data`.`subject`.`progID`       AS `progID`,
    `school_data`.`subject`.`course`       AS `course`,
    `school_data`.`subject`.`course_code`  AS `course_code`,
    `school_data`.`subject`.`course_level` AS `course_level`,
    `school_data`.`subject`.`credit`       AS `credit`,
    `school_data`.`subject`.`semester`     AS `semester`,
    `school_data`.`subject`.`statusID`     AS `statusID`,
    `school_data`.`programme`.`programme`  AS `programme`
  FROM (`school_data`.`subject`
    JOIN `school_data`.`programme` ON ((`school_data`.`subject`.`progID` = `school_data`.`programme`.`progID`)));
