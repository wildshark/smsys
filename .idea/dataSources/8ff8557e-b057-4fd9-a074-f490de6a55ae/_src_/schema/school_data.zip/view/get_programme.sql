CREATE VIEW get_programme AS
  SELECT
    `school_data`.`programme`.`progID`    AS `progID`,
    `school_data`.`programme`.`programme` AS `programme`,
    `school_data`.`programme`.`schoolID`  AS `schoolID`,
    `school_data`.`programme`.`statusID`  AS `statusID`,
    `school_data`.`school`.`school`       AS `school`,
    `school_data`.`school`.`prefix`       AS `prefix`
  FROM (`school_data`.`programme`
    JOIN `school_data`.`school` ON ((`school_data`.`programme`.`schoolID` = `school_data`.`school`.`schoolID`)));
