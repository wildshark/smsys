CREATE VIEW get_student_index_list AS
  SELECT
    `school_data`.`student_profile`.`studentID`   AS `studentID`,
    `school_data`.`student_profile`.`first_name`  AS `first_name`,
    `school_data`.`student_profile`.`surname`     AS `surname`,
    `school_data`.`student_profile`.`admissionNo` AS `admissionNo`,
    `school_data`.`student_profile`.`statusID`    AS `statusID`
  FROM `school_data`.`student_profile`
  WHERE (`school_data`.`student_profile`.`statusID` = 1)
  ORDER BY `school_data`.`student_profile`.`admissionNo`;
