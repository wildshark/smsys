CREATE VIEW get_position AS
  SELECT
    `school_data`.`position_list`.`positionID` AS `positionID`,
    `school_data`.`position_list`.`position`   AS `position`,
    `school_data`.`position_list`.`statusId`   AS `statusId`
  FROM `school_data`.`position_list`;
