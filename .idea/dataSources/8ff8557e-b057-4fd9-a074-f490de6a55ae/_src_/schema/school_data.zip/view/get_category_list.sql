CREATE VIEW get_category_list AS
  SELECT
    `school_data`.`category_list`.`categoryID`       AS `categoryID`,
    `school_data`.`category_list`.`category_name`    AS `category_name`,
    `school_data`.`category_list`.`classificationID` AS `classificationID`
  FROM `school_data`.`category_list`;
