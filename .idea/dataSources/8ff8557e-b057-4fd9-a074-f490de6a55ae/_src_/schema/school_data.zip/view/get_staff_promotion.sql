CREATE VIEW get_staff_promotion AS
  SELECT
    `school_data`.`staff_promotion`.`promotionID` AS `promotionID`,
    `school_data`.`staff_promotion`.`profileID`   AS `profileID`,
    `school_data`.`staff_promotion`.`promo_date`  AS `promo_date`,
    `school_data`.`staff_promotion`.`approve`     AS `approve`,
    `school_data`.`staff_promotion`.`positionID`  AS `positionID`,
    `school_data`.`position_list`.`position`      AS `position`
  FROM (`school_data`.`staff_promotion`
    JOIN `school_data`.`position_list`
      ON ((`school_data`.`staff_promotion`.`positionID` = `school_data`.`position_list`.`positionID`)));
