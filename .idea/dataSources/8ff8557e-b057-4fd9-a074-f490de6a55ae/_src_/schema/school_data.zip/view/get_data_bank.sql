CREATE VIEW get_data_bank AS
  SELECT
    `school_data`.`file_storage`.`shareID`    AS `shareID`,
    `school_data`.`file_storage`.`departID`   AS `departID`,
    `school_data`.`file_storage`.`date`       AS `date`,
    `school_data`.`file_storage`.`title`      AS `title`,
    `school_data`.`file_storage`.`note`       AS `note`,
    `school_data`.`file_storage`.`file_path`  AS `file_path`,
    `school_data`.`file_storage`.`file_seize` AS `file_seize`,
    `school_data`.`file_storage`.`file_type`  AS `file_type`,
    `school_data`.`file_storage`.`statusID`   AS `statusID`
  FROM `school_data`.`file_storage`;
