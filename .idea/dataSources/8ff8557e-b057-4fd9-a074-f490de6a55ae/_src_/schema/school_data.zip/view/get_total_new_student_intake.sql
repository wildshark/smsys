CREATE VIEW get_total_new_student_intake AS
  SELECT
    count(`school_data`.`new_student`.`admissionID`) AS `total_student`,
    `school_data`.`new_student`.`yearID`             AS `yearID`,
    `school_data`.`new_student`.`progID`             AS `progID`
  FROM `school_data`.`new_student`
  GROUP BY `school_data`.`new_student`.`yearID`, `school_data`.`new_student`.`progID`;
