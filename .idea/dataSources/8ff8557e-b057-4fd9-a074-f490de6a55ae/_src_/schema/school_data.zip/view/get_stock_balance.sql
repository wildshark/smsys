CREATE VIEW get_stock_balance AS
  SELECT
    `school_data`.`stock_details`.`stockID`                                                         AS `stockID`,
    sum(`school_data`.`stock_details`.`purchase_qty`)                                               AS `purchase`,
    sum(`school_data`.`stock_details`.`issue_qty`)                                                  AS `issue`,
    sum((`school_data`.`stock_details`.`purchase_qty` - `school_data`.`stock_details`.`issue_qty`)) AS `bal_qty`,
    `school_data`.`stock_main`.`stock`                                                              AS `stock`
  FROM (`school_data`.`stock_details`
    JOIN `school_data`.`stock_main`
      ON ((`school_data`.`stock_details`.`stockID` = `school_data`.`stock_main`.`stockID`)))
  GROUP BY `school_data`.`stock_details`.`stockID`, `school_data`.`stock_main`.`stock`;
