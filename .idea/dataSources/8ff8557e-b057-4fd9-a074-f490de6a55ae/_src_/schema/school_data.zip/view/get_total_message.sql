CREATE VIEW get_total_message AS
  SELECT
    count(`school_data`.`message`.`msgDate`) AS `total`,
    `school_data`.`message`.`stateID`        AS `stateID`,
    `school_data`.`message`.`userID`         AS `userID`
  FROM `school_data`.`message`
  WHERE (`school_data`.`message`.`stateID` = 1);
