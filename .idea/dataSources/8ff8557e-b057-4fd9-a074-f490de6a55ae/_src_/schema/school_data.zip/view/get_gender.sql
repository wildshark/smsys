CREATE VIEW get_gender AS
  SELECT
    `school_data`.`gender`.`genderID`    AS `genderID`,
    `school_data`.`gender`.`gender_type` AS `gender_type`
  FROM `school_data`.`gender`;
