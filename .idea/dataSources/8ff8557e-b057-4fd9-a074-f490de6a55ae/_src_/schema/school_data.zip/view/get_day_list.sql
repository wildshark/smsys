CREATE VIEW get_day_list AS
  SELECT
    `school_data`.`day_list`.`dayID`    AS `dayID`,
    `school_data`.`day_list`.`day_type` AS `day_type`
  FROM `school_data`.`day_list`;
