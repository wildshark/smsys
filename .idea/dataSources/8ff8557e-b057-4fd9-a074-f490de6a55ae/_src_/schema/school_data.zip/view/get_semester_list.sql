CREATE VIEW get_semester_list AS
  SELECT
    `school_data`.`semester_list`.`semesterID` AS `semesterID`,
    `school_data`.`semester_list`.`semester`   AS `semester`,
    `school_data`.`semester_list`.`start_date` AS `start_date`,
    `school_data`.`semester_list`.`end_date`   AS `end_date`,
    `school_data`.`semester_list`.`yearID`     AS `yearID`,
    `school_data`.`semester_list`.`statusID`   AS `statusID`
  FROM `school_data`.`semester_list`;
