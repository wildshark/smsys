CREATE VIEW get_marital_status AS
  SELECT
    `school_data`.`category_list`.`categoryID`       AS `categoryID`,
    `school_data`.`category_list`.`category_name`    AS `marital_status`,
    `school_data`.`category_list`.`classificationID` AS `classificationID`
  FROM `school_data`.`category_list`
  WHERE (`school_data`.`category_list`.`classificationID` = 3);
