CREATE VIEW get_total_department_staff AS
  SELECT
    count(`school_data`.`staff_profile`.`staff_profile_ID`) AS `total`,
    `school_data`.`staff_profile`.`departmentID`            AS `departmentID`
  FROM `school_data`.`staff_profile`
  GROUP BY `school_data`.`staff_profile`.`departmentID`;
