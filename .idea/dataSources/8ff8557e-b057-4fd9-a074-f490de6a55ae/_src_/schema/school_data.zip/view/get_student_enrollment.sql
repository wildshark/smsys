CREATE VIEW get_student_enrollment AS
  SELECT
    `school_data`.`enrollment`.`enrollID`    AS `enrollID`,
    `school_data`.`enrollment`.`enroll_date` AS `enroll_date`,
    `school_data`.`enrollment`.`studentID`   AS `studentID`,
    `school_data`.`enrollment`.`semesterID`  AS `semesterID`,
    `school_data`.`enrollment`.`yearID`      AS `yearID`,
    `school_data`.`enrollment`.`progID`      AS `progID`,
    `school_data`.`programme`.`programme`    AS `programme`,
    `school_data`.`semester`.`semester`      AS `semester`,
    `get_student_index_list`.`first_name`    AS `first_name`,
    `get_student_index_list`.`surname`       AS `surname`,
    `get_student_index_list`.`admissionNo`   AS `admissionNo`,
    `school_data`.`school`.`prefix`          AS `prefix`
  FROM ((((`school_data`.`enrollment`
    JOIN `school_data`.`programme` ON ((`school_data`.`enrollment`.`progID` = `school_data`.`programme`.`progID`))) JOIN
    `school_data`.`semester`
      ON ((`school_data`.`semester`.`semesterID` = `school_data`.`enrollment`.`semesterID`))) JOIN
    `school_data`.`get_student_index_list`
      ON ((`school_data`.`enrollment`.`studentID` = `get_student_index_list`.`studentID`))) JOIN `school_data`.`school`
      ON ((`school_data`.`programme`.`schoolID` = `school_data`.`school`.`schoolID`)));
