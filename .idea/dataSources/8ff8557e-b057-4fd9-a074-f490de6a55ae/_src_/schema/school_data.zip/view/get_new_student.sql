CREATE VIEW get_new_student AS
  SELECT
    `school_data`.`new_student`.`admissionID` AS `admissionID`,
    `school_data`.`new_student`.`date`        AS `date`,
    `school_data`.`new_student`.`student`     AS `student`,
    `school_data`.`new_student`.`mobile`      AS `mobile`,
    `school_data`.`new_student`.`yearID`      AS `yearID`,
    `school_data`.`new_student`.`progID`      AS `progID`,
    `school_data`.`new_student`.`streaID`     AS `streaID`,
    `school_data`.`new_student`.`proofID`     AS `proofID`,
    `school_data`.`new_student`.`serial_no`   AS `serial_no`,
    `school_data`.`programme`.`programme`     AS `programme`,
    `school_data`.`school`.`school`           AS `school`,
    `school_data`.`school`.`prefix`           AS `prefix`,
    `school_data`.`new_student`.`email`       AS `email`,
    `school_data`.`new_student`.`nationality` AS `nationality`,
    `school_data`.`new_student`.`exam_result` AS `exam_result`,
    `school_data`.`new_student`.`categoryID`  AS `categoryID`
  FROM ((`school_data`.`new_student`
    JOIN `school_data`.`programme`
      ON ((`school_data`.`programme`.`progID` = `school_data`.`new_student`.`progID`))) JOIN `school_data`.`school`
      ON ((`school_data`.`school`.`schoolID` = `school_data`.`programme`.`schoolID`)));
