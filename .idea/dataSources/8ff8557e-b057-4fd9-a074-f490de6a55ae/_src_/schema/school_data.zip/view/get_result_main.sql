CREATE VIEW get_result_main AS
  SELECT
    `school_data`.`result_main`.`result_semID` AS `result_semID`,
    `school_data`.`result_main`.`result_date`  AS `result_date`,
    `school_data`.`result_main`.`schoolID`     AS `schoolID`,
    `school_data`.`result_main`.`staffID`      AS `staffID`,
    `school_data`.`result_main`.`levelID`      AS `levelID`,
    `school_data`.`result_main`.`yearID`       AS `yearID`,
    `school_data`.`result_main`.`semesterID`   AS `semesterID`,
    `school_data`.`result_main`.`courseID`     AS `courseID`,
    `school_data`.`school`.`school`            AS `school`,
    `school_data`.`school`.`prefix`            AS `prefix`,
    `school_data`.`staff_profile`.`f_name`     AS `f_name`,
    `school_data`.`staff_profile`.`l_name`     AS `l_name`,
    `school_data`.`semester_list`.`semester`   AS `semester`,
    `school_data`.`course`.`course`            AS `course`,
    `school_data`.`course`.`course_code`       AS `course_code`
  FROM ((((`school_data`.`result_main`
    JOIN `school_data`.`school` ON ((`school_data`.`result_main`.`schoolID` = `school_data`.`school`.`schoolID`))) JOIN
    `school_data`.`staff_profile`
      ON ((`school_data`.`result_main`.`staffID` = `school_data`.`staff_profile`.`staff_profile_ID`))) JOIN
    `school_data`.`semester_list`
      ON ((`school_data`.`result_main`.`semesterID` = `school_data`.`semester_list`.`semesterID`))) JOIN
    `school_data`.`course` ON ((`school_data`.`result_main`.`courseID` = `school_data`.`course`.`courseID`)));
