CREATE VIEW get_hostel_rental AS
  SELECT
    `school_data`.`hostel_rental`.`rentalID`               AS `rentalID`,
    `school_data`.`hostel_rental`.`refNo`                  AS `refNo`,
    `school_data`.`hostel_rental`.`tranDate`               AS `tranDate`,
    `school_data`.`hostel_rental`.`group`                  AS `group`,
    `school_data`.`hostel_rental`.`people`                 AS `people`,
    `school_data`.`hostel_rental`.`start_date`             AS `start_date`,
    `school_data`.`hostel_rental`.`end_date`               AS `end_date`,
    (curdate() - `school_data`.`hostel_rental`.`end_date`) AS `NoOfDays`
  FROM `school_data`.`hostel_rental`;
