CREATE VIEW get_operation_work AS
  SELECT
    `school_data`.`category_list`.`categoryID`       AS `categoryID`,
    `school_data`.`category_list`.`category_name`    AS `work_time`,
    `school_data`.`category_list`.`classificationID` AS `classificationID`
  FROM `school_data`.`category_list`
  WHERE (`school_data`.`category_list`.`classificationID` = 5);
