CREATE VIEW get_countries AS
  SELECT
    `school_data`.`countries`.`alpha_2_code` AS `alpha_2_code`,
    `school_data`.`countries`.`alpha_3_code` AS `alpha_3_code`,
    `school_data`.`countries`.`country`      AS `country`,
    `school_data`.`countries`.`nationality`  AS `nationality`,
    `school_data`.`countries`.`countryID`    AS `countryID`
  FROM `school_data`.`countries`;
